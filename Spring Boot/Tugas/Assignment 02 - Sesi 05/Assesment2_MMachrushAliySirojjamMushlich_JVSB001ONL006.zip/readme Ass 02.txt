=======================================================
Nama: 
-- M. Machrush Aliy Sirojjam Mushlich
Kode Peserta: 
-- JVSB001ONL006
Link GitHub: 
-- https://github.com/jampirojam
=======================================================

PANDUAN PENGGUNAAN APLIKASI

======================================================
CARA RUNNING APP
________________
Cara 1
- Buka terminal, masuk ke direktori.
- ketik javac NamaFile.java && java NamaFile

Cara 2
- Langsung run melalui IDE atau code editor
=======================================================

Latihan_1

Penggunaan Array dimaksudkan untuk menyimpan data, yang kemudian data tersebut diolah berdasarkan kebutuhan.
____________

Latihan_2

Penggunaan Array 2d dimaksudkan untuk menentukan pola bangku di kelas sebelum diduduki oleh siswanya
____________

Latihan_3

Jika nilai inputan >= 1000000, maka pembelian akan mendapatkan diskon
___________

Latihan_4

Apabila nilai sisa hasil bagi tahun dengan 4 habis, maka dapat dipastikan tahun tersebut adalah tahun kabisat, sedang untuk menandainya adalah dengan terdapatnya 29 hari pada bulan Februari (2)
___________

Latihan_5

- Pembuatan invoice ini lebih ke penyimapanan data, yakni dengan menggunakan Array. 
- Pembuatan format currency juga diperlukan untuk membedakan antara nilai nominal uang dengan yang lainnya.