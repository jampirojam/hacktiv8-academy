<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>section_History                            _838eda</name>
   <tag></tag>
   <elementGuidId>cb39973b-f6ec-4966-960d-0e34dcf37c30</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#history</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='history']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>section</value>
      <webElementGuid>a092825e-757a-4622-8665-5e77a4f7b6f5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>history</value>
      <webElementGuid>d310d5fe-1f7e-4dc7-ba88-1b96f7a4f49f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>section</value>
      <webElementGuid>a1d3bbe1-5e10-4343-a622-f2a9ed0c6449</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
            
                History
                
                            
        
        
                        
                
                    30/07/2022
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Medical check-up routine
                        
                    
                
            
                    
        
            Go to Homepage
        
    
</value>
      <webElementGuid>130417e5-4e9e-49e9-90d9-29a1fa3b818c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;history&quot;)</value>
      <webElementGuid>0f60c7b8-df96-4de4-87bd-0bdeec10c6e1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//section[@id='history']</value>
      <webElementGuid>c5dd16c2-a8a1-4fff-8247-99b3c56b78eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Make Appointment'])[1]/following::section[1]</value>
      <webElementGuid>135b361e-bd80-4f07-83b9-8f55dbad5141</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='We Care About Your Health'])[1]/following::section[1]</value>
      <webElementGuid>42bf3294-4ca1-4804-9479-340530076d84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section</value>
      <webElementGuid>ac9861f2-8eaa-4576-811a-1207971eacf3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//section[@id = 'history' and (text() = '
    
        
            
                History
                
                            
        
        
                        
                
                    30/07/2022
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Medical check-up routine
                        
                    
                
            
                    
        
            Go to Homepage
        
    
' or . = '
    
        
            
                History
                
                            
        
        
                        
                
                    30/07/2022
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Medical check-up routine
                        
                    
                
            
                    
        
            Go to Homepage
        
    
')]</value>
      <webElementGuid>6ecb95c7-e3d8-4eb5-92e8-c09296794658</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
